// ============================================================================
// YKS Sayaç — Yedekleme: dışa aktarma, otomatik yedek, yedekten geri yükleme
// Klasik <script> (IIFE değil): üst düzey tanımlar diğer dosyalarla ortak global kapsamdadır.
// Yükleme sırası yks-sayac.html içindeki <script> sırasıdır.
// ============================================================================

// ---- Veri Yedekleme ----

var BACKUP_PREFIXES = ["progress-", "topics-", "study-", "streak-celebrated-"];
var BACKUP_SINGLE_KEYS = ["yks-settings", "notes-pages", "focus-city", "deneme-records"];
function collectAllBackupKeys() {
  return Promise.all(BACKUP_PREFIXES.map(function (p) { return storageListKeys(p); }))
    .then(function (results) {
      var all = BACKUP_SINGLE_KEYS.slice();
      results.forEach(function (keys) { all = all.concat(keys); });
      var seen = {};
      return all.filter(function (k) {
        if (seen[k]) return false;
        seen[k] = true;
        return true;
      });
    });
}
function exportBackup() {
  return collectAllBackupKeys().then(function (keys) {
    return Promise.all(keys.map(function (key) {
      return storageGet(key).then(function (value) { return { key: key, value: value }; });
    }));
  }).then(function (entries) {
    var data = {};
    entries.forEach(function (e) {
      if (e.value !== null && e.value !== undefined) data[e.key] = e.value;
    });
    return { app: "yks-sayac", exportedAt: new Date().toISOString(), version: 1, data: data };
  });
}
function showBackupStatus(text, isError) {
  var noteEl = document.getElementById("backupStatusNote");
  if (!noteEl) return;
  noteEl.textContent = text;
  noteEl.style.color = isError ? "var(--danger)" : "var(--ink-dim)";
}
function downloadBackupFile() {
  return exportBackup().then(function (payload) {
    var count = Object.keys(payload.data).length;
    var json = JSON.stringify(payload, null, 2);
    var blob = new Blob([json], { type: "application/json" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = "yks-sayac-yedek-" + dateStr(new Date()) + ".json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    return { ok: true, count: count };
  }).catch(function (err) {
    console.error("Yedek alma hatası:", err);
    return { ok: false, error: err };
  });
}
function maybeAutoBackup() {
  var todayStr = dateStr(new Date());
  storageGet("auto-backup-last-date").then(function (value) {
    if (value === todayStr) return;
    downloadBackupFile().then(function (res) {
      if (res && res.ok) storageSet("auto-backup-last-date", todayStr);
    });
  }).catch(function (err) { console.error("Otomatik yedekleme hatası:", err); });
}
var pendingRestoreData = null;
function restoreBackupFromFile(file) {
  showBackupStatus("", false);
  var reader = new FileReader();
  reader.onload = function () {
    var parsed;
    try {
      parsed = JSON.parse(reader.result);
    } catch (e) {
      showBackupStatus("Dosya okunamadı. Geçerli bir yedek (.json) dosyası seç.", true);
      return;
    }
    if (!parsed || typeof parsed.data !== "object" || !parsed.data) {
      showBackupStatus("Bu dosya geçerli bir YKS Sayaç yedeği gibi görünmüyor.", true);
      return;
    }
    var keys = Object.keys(parsed.data);
    if (!keys.length) {
      showBackupStatus("Yedek dosyası boş görünüyor.", true);
      return;
    }
    pendingRestoreData = parsed.data;
    var box = document.getElementById("backupConfirmBox");
    var text = document.getElementById("backupConfirmText");
    if (text) {
      text.textContent = keys.length + " kayıt geri yüklenecek ve mevcut verilerin üzerine yazılacak. Onaylıyor musun?";
    }
    if (box) box.classList.add("open");
  };
  reader.onerror = function () {
    showBackupStatus("Dosya okunamadı.", true);
  };
  reader.readAsText(file, "utf-8");
}
function cancelPendingRestore() {
  pendingRestoreData = null;
  var box = document.getElementById("backupConfirmBox");
  if (box) box.classList.remove("open");
}
function confirmPendingRestore() {
  if (!pendingRestoreData) return;
  var keys = Object.keys(pendingRestoreData);
  var data = pendingRestoreData;
  var box = document.getElementById("backupConfirmBox");
  if (box) box.classList.remove("open");
  showBackupStatus("Geri yükleniyor…", false);
  // Not sayfalarının HTML içeriği geri yüklenirken temizlenir (yedek dosyası güvenilmez girdidir)
  if (typeof data["notes-pages"] === "string") {
    try {
      var np = JSON.parse(data["notes-pages"]);
      if (np && Array.isArray(np.pages)) {
        np.pages.forEach(function (pg) {
          if (!pg || typeof pg !== "object") return;
          pg.content = sanitizeNoteHtml(pg.content || "");
          pg.title = String(pg.title || "").slice(0, 300);
          pg.tag = String(pg.tag || "").slice(0, 100);
        });
        data["notes-pages"] = JSON.stringify(np);
      }
    } catch (e) {}
  }
  Promise.all(keys.map(function (k) { return storageSet(k, data[k]); })).then(function () {
    pendingRestoreData = null;
    showBackupStatus(keys.length + " kayıt geri yüklendi. Sayfa yenileniyor…", false);
    setTimeout(function () { location.reload(); }, 900);
  }).catch(function (err) {
    console.error("Geri yükleme hatası:", err);
    showBackupStatus("Geri yükleme sırasında bir hata oluştu.", true);
  });
}
