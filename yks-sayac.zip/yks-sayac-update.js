// ============================================================================
// YKS Sayaç — Güncelleme kontrolü ve otomatik güncelleme
// Klasik <script> (IIFE değil): üst düzey tanımlar diğer dosyalarla ortak global kapsamdadır.
// Yükleme sırası yks-sayac.html içindeki <script> sırasıdır.
// ============================================================================

// --- Guncelleme kontrolu ve otomatik guncelleme ---
// Firestore'daki appConfig/latestVersion belgesindeki "version" alanini
// yerel APP_VERSION ile karsilastirir. "downloadUrl" alani da varsa,
// dosyalari INDIRME/DEGISTIRME islemini otomatik olarak arka planda
// yaptirir (yerel sunucudaki /apply-update ucuna haber vererek - bu is
// tarayicinin degil, PowerShell sunucusunun dosya erisimiyle yapiliyor).
// Calisan sayfa hemen yeniden yuklenmez; degisiklikler bir dahaki
// acilista devreye girer, istenirse "Simdi Yenile" ile hemen de olur.
function compareVersions(a, b) {
  var pa = String(a || "0").split(".").map(function (n) { return parseInt(n, 10) || 0; });
  var pb = String(b || "0").split(".").map(function (n) { return parseInt(n, 10) || 0; });
  var len = Math.max(pa.length, pb.length);
  for (var i = 0; i < len; i++) {
    var da = pa[i] || 0, db = pb[i] || 0;
    if (da > db) return 1;
    if (da < db) return -1;
  }
  return 0;
}
function showUpdateToast(message) {
  var el = document.getElementById("updateToast");
  if (!el) {
    el = document.createElement("div");
    el.id = "updateToast";
    el.setAttribute("role", "status");
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(showUpdateToast._t);
  showUpdateToast._t = setTimeout(function () { el.classList.remove("show"); }, 8000);
}
function showUpdateToastOnce(remoteVersion, message) {
  storageGet("update-toast-shown-version").then(function (shownVersion) {
    if (shownVersion === remoteVersion) return;
    showUpdateToast(message);
    storageSet("update-toast-shown-version", remoteVersion);
  }).catch(function () {});
}
function setUpdateBadge(on) {
  var settingsBtn = document.getElementById("settingsBtn");
  if (settingsBtn) {
    if (on) settingsBtn.classList.add("has-update-badge");
    else settingsBtn.classList.remove("has-update-badge");
  }
}
function applyAutoUpdate(downloadUrl, remoteVersion, message, isManualRetry) {
  var note = document.getElementById("versionNote");
  var btn = document.getElementById("updateNowBtn");
  if (btn) { btn.disabled = true; btn.style.display = "none"; }
  if (note) note.textContent = "Yeni sürüm indiriliyor (v" + remoteVersion + ")…";

  // Sunucu bu ucu yalnizca POST + ayni-origin + ozel baslik ile kabul eder ve
  // sadece sabitlenmis GitHub deposundan indirir (bkz. _yks_server.ps1).
  fetch("/apply-update?url=" + encodeURIComponent(downloadUrl), {
    method: "POST",
    body: "",
    headers: { "X-YKS-Update": "1" },
    credentials: "same-origin"
  })
    .then(function (res) { return res.json(); })
    .then(function (result) {
      if (result && result.ok) {
        if (note) {
          note.textContent = "Sürüm " + APP_VERSION + " · v" + remoteVersion + " indirildi, bir dahaki açılışta devreye girecek.";
          note.classList.add("settings-note-attention");
        }
        if (btn) {
          btn.textContent = "Şimdi Yenile";
          btn.style.display = "inline-flex";
          btn.disabled = false;
          btn.onclick = function () { location.reload(); };
        }
        setUpdateBadge(true);
        showUpdateToastOnce(remoteVersion, "Yeni sürüm indirildi (v" + remoteVersion + "). Bir dahaki açılışta devreye girecek.");
      } else {
        // Otomatik kurulum basarisiz oldu - en azindan bildirim olarak goster.
        var reason = (result && result.error) ? result.error : "";
        if (note) {
          note.textContent = "Sürüm " + APP_VERSION + " · yeni sürüm var: v" + remoteVersion +
            (message ? " — " + message : "") + " (otomatik güncelleme başarısız" + (reason ? ": " + reason : "") + ").";
          note.classList.add("settings-note-attention");
        }
        if (btn) {
          btn.textContent = "Tekrar Dene";
          btn.style.display = "inline-flex";
          btn.disabled = false;
          btn.onclick = function () { applyAutoUpdate(downloadUrl, remoteVersion, message, true); };
        }
        setUpdateBadge(true);
        if (!isManualRetry) {
          showUpdateToastOnce(remoteVersion, "Yeni bir sürüm var (v" + remoteVersion + ") ama otomatik güncelleme başarısız oldu.");
        }
      }
    })
    .catch(function () {
      if (note) {
        note.textContent = "Sürüm " + APP_VERSION + " · yeni sürüm var: v" + remoteVersion +
          (message ? " — " + message : "") + " (otomatik güncelleme başarısız).";
        note.classList.add("settings-note-attention");
      }
      if (btn) {
        btn.textContent = "Tekrar Dene";
        btn.style.display = "inline-flex";
        btn.disabled = false;
        btn.onclick = function () { applyAutoUpdate(downloadUrl, remoteVersion, message, true); };
      }
      setUpdateBadge(true);
    });
}
function applyUpdateAvailableUI(remoteVersion, message, downloadUrl) {
  if (downloadUrl) {
    applyAutoUpdate(downloadUrl, remoteVersion, message, false);
    return;
  }
  // downloadUrl verilmediyse (henuz hazirlanmadiysa) sadece bildir.
  var note = document.getElementById("versionNote");
  if (note) {
    note.textContent = "Sürüm " + APP_VERSION + " · yeni sürüm var: v" + remoteVersion +
      (message ? " — " + message : "") + ".";
    note.classList.add("settings-note-attention");
  }
  setUpdateBadge(true);
  showUpdateToastOnce(remoteVersion, "Yeni bir sürüm var (v" + remoteVersion + "). Ayarlar'dan detay gör.");
}
function checkForUpdate() {
  var note = document.getElementById("versionNote");
  if (note) note.textContent = "Sürüm " + APP_VERSION;
  fbDb.collection("appConfig").doc("latestVersion").get().then(function (doc) {
    if (!doc.exists) return;
    var data = doc.data() || {};
    if (data.version && compareVersions(data.version, APP_VERSION) > 0) {
      applyUpdateAvailableUI(data.version, data.message, data.downloadUrl);
    }
  }).catch(function () {
    // Sürüm kontrolü başarısız olursa (örn. çevrimdışı) sessizce geç -
    // bu, widget'ın açılmasını asla engellememeli.
  });
}
