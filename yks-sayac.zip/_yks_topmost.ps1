$deadline = (Get-Date).AddSeconds(15)
$hwnd = [IntPtr]::Zero
while ((Get-Date) -lt $deadline -and $hwnd -eq [IntPtr]::Zero) {
  Start-Sleep -Milliseconds 400
  $p = Get-Process -Name brave,msedge,chrome -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like '*YKS*' }
  if ($p) { $hwnd = ($p | Select-Object -First 1).MainWindowHandle }
}
if ($hwnd -ne [IntPtr]::Zero) {
  Add-Type -Name Win32 -Namespace YksSayac -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);'
  [YksSayac.Win32]::SetWindowPos($hwnd, [IntPtr](-1), 0, 0, 0, 0, 0x0001 -bor 0x0002)
}
