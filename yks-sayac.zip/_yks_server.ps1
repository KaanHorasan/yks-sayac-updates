# YKS Sayac - Yerel HTTP Sunucusu
# Amac: dosyayi file:// yerine http://localhost uzerinden sunup Firestore'un
# ayni-origin koprusunu kullanabilmesini saglamak. Harici bagimlilik yok,
# Windows'ta hazir gelen .NET siniflarini kullanir.

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 8917

function Test-PortFree($p) {
  try {
    $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)
    $listener.Start()
    $listener.Stop()
    return $true
  } catch {
    return $false
  }
}

# Zaten calisan bir sunucu varsa (onceki oturumdan kalmis olabilir) tekrar baslatma
if (-not (Test-PortFree $port)) {
  exit
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
try {
  $listener.Start()
} catch {
  exit
}

$mimeMap = @{
  ".html" = "text/html; charset=utf-8"
  ".htm"  = "text/html; charset=utf-8"
  ".js"   = "application/javascript; charset=utf-8"
  ".css"  = "text/css; charset=utf-8"
  ".json" = "application/json; charset=utf-8"
  ".png"  = "image/png"
  ".jpg"  = "image/jpeg"
  ".jpeg" = "image/jpeg"
  ".svg"  = "image/svg+xml"
  ".ico"  = "image/x-icon"
  ".woff" = "font/woff"
  ".woff2"= "font/woff2"
}

while ($listener.IsListening) {
  try {
    $context = $listener.GetContext()
  } catch {
    break
  }
  try {
    $request = $context.Request
    $response = $context.Response
    $response.Headers.Add("Cache-Control", "no-store, must-revalidate")

    $localPath = [System.Uri]::UnescapeDataString($request.Url.LocalPath).TrimStart("/")
    if ([string]::IsNullOrEmpty($localPath)) { $localPath = "yks-sayac.html" }

    if ($localPath -eq "apply-update") {
      # Otomatik guncelleme: widget (tarayici tarafi) burayi cagirip bir
      # ZIP URL'si veriyor. Bu betik ZIP'i indirip, icindeki dosyalari
      # DOGRUDAN bu klasorun uzerine kopyaliyor. Sadece localhost'tan
      # erisilebildigi icin (HttpListener loopback'e bagli) ekstra bir
      # yetkilendirmeye gerek yok - bu sinir zaten tum uygulamanin
      # guvendigi sinirin aynisi.
      $updateUrl = $request.QueryString["url"]
      $result = @{ ok = $false; error = "" }
      if ([string]::IsNullOrWhiteSpace($updateUrl)) {
        $result.error = "url parametresi eksik"
      } elseif ($updateUrl -notmatch '^https://') {
        $result.error = "sadece https:// adresleri kabul edilir"
      } else {
        $tempZip = Join-Path $env:TEMP ("yks-sayac-update-" + [guid]::NewGuid().ToString("N") + ".zip")
        $tempExtract = Join-Path $env:TEMP ("yks-sayac-update-" + [guid]::NewGuid().ToString("N"))
        try {
          $ProgressPreference = "SilentlyContinue"
          Invoke-WebRequest -Uri $updateUrl -OutFile $tempZip -UseBasicParsing -TimeoutSec 60
          Expand-Archive -Path $tempZip -DestinationPath $tempExtract -Force

          # ZIP'in icinde dosyalar dogrudan mi yoksa tek bir alt klasorde mi -
          # ikisini de destekle.
          $sourceRoot = $tempExtract
          $entries = Get-ChildItem -Path $tempExtract
          if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) {
            $sourceRoot = $entries[0].FullName
          }

          Get-ChildItem -Path $sourceRoot -File -Recurse | ForEach-Object {
            Copy-Item -Path $_.FullName -Destination (Join-Path $scriptDir $_.Name) -Force
          }

          $result.ok = $true
        } catch {
          $result.error = $_.Exception.Message
        } finally {
          Remove-Item -Path $tempZip -Force -ErrorAction SilentlyContinue
          Remove-Item -Path $tempExtract -Recurse -Force -ErrorAction SilentlyContinue
        }
      }

      $json = ($result | ConvertTo-Json -Compress)
      $jsonBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
      $response.ContentType = "application/json; charset=utf-8"
      $response.ContentLength64 = $jsonBytes.Length
      $response.OutputStream.Write($jsonBytes, 0, $jsonBytes.Length)
    } else {
      # Klasor disina cikan istekleri engelle (basit guvenlik)
      $filePath = Join-Path $scriptDir $localPath
      $fullScriptDir = (Resolve-Path $scriptDir).Path
      $resolvedRequested = $null
      if (Test-Path $filePath -PathType Leaf) {
        $resolvedRequested = (Resolve-Path $filePath).Path
      }

      if ($resolvedRequested -and $resolvedRequested.StartsWith($fullScriptDir)) {
        $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
        $contentType = if ($mimeMap.ContainsKey($ext)) { $mimeMap[$ext] } else { "application/octet-stream" }
        $bytes = [System.IO.File]::ReadAllBytes($filePath)
        $response.ContentType = $contentType
        $response.ContentLength64 = $bytes.Length
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
      } else {
        $response.StatusCode = 404
        $notFoundBytes = [System.Text.Encoding]::UTF8.GetBytes("404 - dosya bulunamadi")
        $response.OutputStream.Write($notFoundBytes, 0, $notFoundBytes.Length)
      }
    }
  } catch {
    try { $context.Response.StatusCode = 500 } catch {}
  } finally {
    try { $context.Response.OutputStream.Close() } catch {}
  }
}
