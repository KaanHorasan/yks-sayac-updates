# YKS Sayaç — Proje Özeti (Devam Notu, güncel)

## Genel Mimari
- **Tek widget**, öğrencinin/koçun kendi bilgisayarında **VBS ile başlatılan** bir HTML uygulaması.
- **ÖNEMLİ — mimari değişti:** artık `file://` ile AÇILMIYOR. Firestore'un gerçek-zamanlı bağlantısı `file://` altında güvenilir çalışmadığı için (Chromium her `file://` yüklemesini benzersiz/izole bir origin sayıyor, bu da Firestore'un aynı-origin köprüleme mekanizmasını bozuyor), widget artık **yerel bir HTTP sunucusundan** (`http://localhost:8917/yks-sayac.html`) açılıyor.
- 5 dosya **her zaman aynı klasörde** olmalı:
  - `yks-sayac.html` — ana widget: HTML+CSS+ana JS mantığı (IIFE, `var`, ES5 tarzı, build/bundler yok)
  - `yks-sayac-images.js` — piksel sanatı varlıklarının base64 hali
  - `yks-sayac-cloud.js` — Firebase Auth + Firestore + koç paneli mantığı (global scope, IIFE değil — html'in IIFE'i içinden `fbAuth`/`fbDb`/`currentUserUid` gibi değişkenlerine doğrudan erişilebiliyor)
  - `yks-sayac-baslat.vbs` — tarayıcı bulur, özel profil oluşturur (`%LOCALAPPDATA%\YksSayacWidgetProfile`), **önce yerel sunucuyu başlatır**, sonra `--app=http://localhost:8917/yks-sayac.html` ile açar
  - `_yks_server.ps1` — **(yeni)** bağımsız, PowerShell `System.Net.HttpListener` tabanlı yerel HTTP sunucu; klasördeki dosyaları `http://localhost:8917/` üzerinden sunar; `Cache-Control: no-store` gönderir (tarayıcı asla eski dosyayı önbellekten kullanmasın diye)
- Ek dosya: `_yks_topmost.ps1` (her zaman üstte tutar, VBS her çalıştığında yeniden yazılır)
- **Önemli:** `.vbs`/`.ps1` dosyalarında Türkçe özel karakterler (ç,ğ,ı,ö,ş,ü) **tamamen ASCII'ye çevrilmiş** durumda kalmalı (Windows Script Host ANSI okuyor, UTF-8 bozuluyor).

## Görünümler (hepsi `yks-sayac.html` içinde, `?view=` parametresiyle ayrılıyor)
- **(param yok)** — ana widget: geri sayım, günlük konu hedefi (artık koçun planından gelen maddeleri de içerebiliyor), motivasyon cümlesi, seri rozeti, ikon sırası (tema/ayarlar/konular/notlar/yedek/şehir/deneme/**plan**/**çıkış**)
- **`?view=topics`** — kronometre, odak modu, şehir mini-kart, çalışma pasta grafiği, günlük hedef, konu listesi (koçun plan maddeleri dahil), 7 günlük geçmiş
- **`?view=notes`** — çok sayfalı notlar
- **`?view=city`** — market + piksel sanatı şehir sahnesi
- **`?view=exam`** — deneme (TYT/AYT) takibi, net grafiği
- **`?view=plan`** — **(yeni)** öğrencinin haftalık planını **tablo** olarak gösterir (Gün/Konu/Süre/Soru/Doğru/Yanlış/Tik), Doğru-Yanlış-Tik hücreleri öğrenci tarafından düzenlenebilir, koçtan gelen genel not varsa üstte gösterilir. Firebase'e giriş gerektirir (`fbAuth.onAuthStateChanged`).
- **`?view=coach`** — koç paneli (ana widget'la aynı pencere/rol bazlı, ayrı bir açılış yolu değil — bkz. Koç Paneli bölümü)

## Yerel Depolama (localStorage) Anahtarları — değişmedi
| Anahtar | İçerik |
|---|---|
| `yks-settings` | `{examDate, examTime, sessionName, dailyGoal, theme}` |
| `progress-YYYY-MM-DD` | string sayı (o günkü tamamlanan konu sayısı) |
| `topics-YYYY-MM-DD` | `[{id, text, done, planTaskId?, planDay?}]` — **planTaskId/planDay varsa** bu madde koçun haftalık planından otomatik eklenmiş demektir (bkz. Haftalık Plan Entegrasyonu) |
| `study-YYYY-MM-DD` | `{subjects:{ders:saniye}, running, activeSubject, startTs}` |
| `notes-pages` | `{pages:[{id,title,tag,content(HTML),updatedAt}], activeId}` |
| `focus-city` | `{buildings:[...], coins, debuffSessionsLeft}` |
| `deneme-records` | `{records:[{id,date,examKey,name,subjects:{ders:{correct,wrong,empty}},totalNet,createdAt}]}` |
| `streak-celebrated-YYYY-MM-DD` | "1" bayrağı |
| `auto-backup-last-date` | tarih string |

**Yedekleme:** `BACKUP_PREFIXES = ["progress-","topics-","study-","streak-celebrated-"]`, `BACKUP_SINGLE_KEYS = ["yks-settings","notes-pages","focus-city","deneme-records"]`. Notlar genel yedeğe dahil ama koça senkron edilmiyor (gizlilik).

## Firebase / Firestore Şeması
**Config** (proje: `yks-koclugu-367ec`):
```js
{
  apiKey: "AIzaSyBuY_hjvqBMdYTeQwEwbUAZ7Ol_1TrEdS8",
  authDomain: "yks-koclugu-367ec.firebaseapp.com",
  projectId: "yks-koclugu-367ec",
  storageBucket: "yks-koclugu-367ec.firebasestorage.app",
  messagingSenderId: "107365183273",
  appId: "1:107365183273:web:94896ac71447b8fa279138",
  measurementId: "G-RR5BZXWPWC"
}
```
SDK: `firebase-app-compat.js` + `firebase-auth-compat.js` + `firebase-firestore-compat.js` (v10.13.2, CDN, compat).

**⚠️ Firestore veritabanı Standard edition, `eur3` (Avrupa) bölgesinde olmalı.** Bir ara yanlışlıkla "Enterprise edition" + `nam5` (Kuzey Amerika) olarak oluşturulmuştu — Enterprise edition'ın web SDK realtime desteği Google'ın kendi dokümantasyonunda "Preview" (kararsız) olarak işaretli, bu da sürekli bağlantı kopma/yeniden bağlanma döngüsüne (her istekte yeni `gsessionid`) yol açıyordu; hem yazma çalışıp okuma çalışmaması hem de genel yavaşlık bundan kaynaklanıyordu. Veritabanı silinip Standard edition + `eur3` olarak yeniden oluşturuldu, sorun tamamen düzeldi. **Yeni bir ortamda/projede bu hatayı tekrarlamayın.**

```js
fbDb.settings({ experimentalForceLongPolling: true });
```
Bu ayar hâlâ kodda duruyor ve **kaldırılmamalı** — bir ara "artık localhost'tayız, gereksiz" diye kaldırılmış ama bu yanlış çıktı: ayrı, ağ/güvenlik-yazılımı kaynaklı bir bağlantı-kopma sorununu maskeleyip düzeltiyor. İki sorun (Enterprise-edition + bu) aynı dönemde üst üste bindiği için karışmıştı; ikisi de gerçekti ve ikisi de çözüldü.

**Koleksiyonlar:**
- `users/{uid}` → `{role:"student"|"coach", name, email, coachId(öğrenci için, null/coach uid), createdAt, inviteCode(sadece koç)}`
- `inviteCodes/{code}` → `{coachUid}` — 6 karakterli, sadece `get` ile okunabilir
- `studentData/{uid}/info/meta` → `{name, streak, cityCoins, cityBuildings, cityPopulation, examCount, bestTYT, bestAYT, lastActive, weeklySubjects, monthlySubjects, allSubjects, examRecords}` — öğrenci girişliyken 3 dakikada bir senkronlanır (`buildStudentSummaryPayload()`, her zaman önce `loadCity()`/`loadExamRecords()`'ın bitmesini bekler — bunu beklemezse ilk senkron boş gider, bu bug bir kere yaşandı ve düzeltildi)
  - `weeklySubjects`/`monthlySubjects`/`allSubjects`: `{dersAdı: saniye}` — sırasıyla son 7 gün / son 30 gün / tüm zamanlar
  - `examRecords`: `[{id, date, examKey, name, totalNet, createdAt, subjects:{ders:{correct,wrong,empty}}}]` — öğrencinin girdiği TÜM denemeler (sadece en iyi net değil)
- `studentData/{uid}/info/plan` → **(yeni)** haftalık plan:
  ```js
  {
    updatedAt: <timestamp>,
    note: "string (opsiyonel, koçun genel notu)",
    days: {
      mon: { "<taskId>": { examType, subject, topic, minutes, questionCount, done, correct, wrong, createdAt }, ... },
      tue: { ... }, wed: { ... }, thu: { ... }, fri: { ... }, sat: { ... }, sun: { ... }
    }
  }
  ```
  - Her gün bir **dizi değil, id ile anahtarlanmış bir map**. Bilerek böyle: Firestore'un nested-object `merge:true` ile derin birleştirme yapması sayesinde, koç yeni madde eklerken/silerken öğrencinin işaretlediği başka bir maddenin tik/doğru/yanlış'ını EZMİYOR, öğrenci de tik atarken koçun eklediği başka bir maddeyi kaybetmiyor. (Array kullanılsaydı Firestore her yazışta diziyi TAMAMEN değiştirir, bu güvenli olmazdı.)
  - `examType`: `"TYT"` veya `"AYT"` — konu, TYT/AYT ayrımlı bir konu havuzundan (`YKS_TOPICS`, cloud.js içinde) seçiliyor.
  - Madde ekleme/silme: `addPlanTask()`/`removePlanTask()` (cloud.js, koç tarafı). Doğru/Yanlış/Tik güncelleme: `savePlanTaskField()` (html, öğrenci tarafı) — her ikisi de nested-object `merge:true` kullanıyor, `removePlanTask` ise `FieldValue.delete()` + `.update()` ile tek bir maddeyi siliyor.
- `studentData/{uid}/planHistory/{weekId}` → **(yeni)** haftalık plan arşivi. `weekId` rastgele üretiliyor (`"w" + Date.now().toString(36) + rastgele`). Her belge: `{archivedAt, weekLabel (örn. "22 Eylül 2026", tr-TR yerelinde üretilir), note, days: <o haftanın tam plan/days objesi, doğru-yanlış-tik dahil>}`. `archivePlanWeek()` yazıyor, `fetchPlanHistory()` en yeni 20 kaydı `archivedAt` azalan sırayla okuyor (cloud.js). Arşivleme ile sıfırlama iki ayrı Firestore yazması (atomik değil) — `archiveAndResetPlanForNewWeek()` önce arşivler, sonra `resetPlanForNewWeek()`'i çağırır. Bu ikisi hem koçun butonundan hem de otomatik haftalık kontrolden (`maybeAutoArchiveWeek()`, `mondayKeyOf()` ile plan.updatedAt'in haftasını bugünle karşılaştırır) çağrılıyor.

**Güvenlik kuralları** (Firebase konsolu → Firestore → Rules → **yayınlanmış, güncel** hali):
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read: if request.auth != null && request.auth.uid == uid;
      allow read: if request.auth != null && resource.data.coachId == request.auth.uid;
      allow create, update: if request.auth != null && request.auth.uid == uid;
      allow delete: if false;
    }
    match /inviteCodes/{code} {
      allow get: if request.auth != null;
      allow create: if request.auth != null;
      allow list, update, delete: if false;
    }
    match /studentData/{studentUid}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == studentUid;
      allow read: if request.auth != null &&
        get(/databases/$(database)/documents/users/$(studentUid)).data.coachId == request.auth.uid;
    }
    match /studentData/{studentUid}/info/plan {
      allow write: if request.auth != null &&
        get(/databases/$(database)/documents/users/$(studentUid)).data.coachId == request.auth.uid;
    }
    match /studentData/{studentUid}/planHistory/{weekId} {
      allow write: if request.auth != null &&
        get(/databases/$(database)/documents/users/$(studentUid)).data.coachId == request.auth.uid;
    }
  }
}
```
(Son iki blok — `info/plan` ve `planHistory/{weekId}` için koça yazma izni — koçun plan editörü ve "haftayı arşivle" butonu için şart. Öğrenci zaten üstteki genel kuralla, `planHistory` dahil kendi verisine tam okuma/yazma sahip. **Yeni kuralı Firebase konsolu → Firestore → Rules'a eklemek/yayınlamak gerekiyor**, yoksa koç panelinden arşivleme "permission-denied" hatası verir.)

## Kimlik Doğrulama Akışı (önemli teknik detaylar)
- `onAuthStateChanged`, sayfa her açıldığında (önceki oturum hatırlanıyorsa) otomatik tetikleniyor. Profil okuması (`firestoreGetWithRetry`) "client is offline" tipi geçici hatalarda 4 kez, artan gecikmelerle (900ms→1.4s→2.3s→3.7s) tekrar deniyor — soğuk başlangıçta Firestore bağlantısı henüz kurulmamışsa diye.
- Kayıt (`registerUser`) sırasında Auth hesabı oluşur oluşmaz `onAuthStateChanged` da AYNI ANDA tetiklenip profili okumaya çalışabiliyordu (henüz `users/{uid}` belgesi/davet-kodu yazılmadan) — bu yarış durumu `pendingAuthTask` ile çözüldü: `onAuthStateChanged`, devam eden bir kayıt/giriş işlemi varsa onun tamamen bitmesini bekliyor.
- Yükleniyor durumları (`setAuthBusy`) buton üzerinde spinner + metin gösteriyor, 15 saniyeyi geçerse otomatik "çok uzun sürdü" hatasına dönüyor.

## Koç Paneli (`role === "coach"`)
- Üstte davet kodu, altta bağlı öğrenci kartları (`fetchCoachStudents` → her öğrenci için `meta` + `plan` paralel çekiliyor).
- **Hafta/Ay/Tümü** seçici (üstte, tüm kartları etkiler) — hangisine göre konu-dağılımı çubuk grafiği çekilsin (`weeklySubjects`/`monthlySubjects`/`allSubjects`).
- Her öğrenci kartı: seri/en iyi TYT net/en iyi AYT net/şehir nüfusu, konu dağılımı çubuk grafiği, **"denemeler (N)"** açılır liste (her satır tıklanınca o denemenin ders-ders Doğru/Yanlış/Boş/net dökümünü açar), **"net grafiği"** açılır bölüm **(yeni)**, **"haftalık plan ✎"** açılır editör.
- **Net grafiği (yeni):** TYT/AYT-SAY/AYT-EA/AYT-SOZ sekmeleri (gerçek `examKey` değerleriyle aynı — öğrenci tarafındaki deneme kayıt sekmeleriyle bire bir eşleşiyor). Seçilen türe ait `examRecords` tarihe göre sıralanıp inline SVG çizgi grafik olarak çiziliyor (`buildCoachNetChartSvg()`, cloud.js — html'deki öğrenci-tarafı `buildNetChartSvg()`'den ilham alındı ama ayrı/küçük bir kopya, iki dosya birbirinin fonksiyonlarına erişemiyor). TYT çizgisi amber, AYT-* çizgileri sage renginde. Altında son net/önceki denemeye göre değişim/ortalama/en yüksek özet rakamları (`buildCoachNetChartStatsHtml()`). İlk açılışta render ediliyor, sekme değiştirmek anında yeniden çiziyor (ekstra Firestore okuması yok, veri zaten `meta.examRecords` içinde geliyor). Gradyan id'leri öğrenci uid + sınav türüne göre üretiliyor (`netGrad_<uid>_<tür>`) — aynı sayfada birden fazla kart olduğu için id çakışmasını önlemek şart.
- **Plan editörü:**
  - Seçici: **TYT/AYT** → **ders** (seçilen sınava göre filtrelenir) → **konu** → **dakika** → **soru sayısı** → **gün** → "+ Ekle" (her tıklamada tek bir Firestore yazması, anında tabloya düşer).
  - Tablo: Gün/Konu(TYT-AYT etiketli)/Süre/Soru/D/Y/Tik/Sil — D/Y/Tik öğrenciden geldiği gibi salt-okunur.
  - Başlıkta tamamlanma rozeti: "%60 tamamlandı (6/10)".
  - **"Haftayı Arşivle ve Sıfırla"** butonu (eski adı "Geçen Haftadan Kopyala…"): önce o haftanın tam durumunu (D/Y/tik dahil) `planHistory`'e kalıcı olarak kaydeder, sonra aynı ders/konu/süre/soru'yu koruyup tüm doğru/yanlış/tik'i sıfırlar (onay penceresi ile). **Manuel yol** — otomatik arşivleme de var, bkz. altta.
  - **Otomatik arşivleme (yeni):** koç paneli her açıldığında (`renderCoachDashboard` → `fetchCoachStudents`), her öğrencinin planı için `maybeAutoArchiveWeek()` çalışır. Planın son güncellendiği haftanın Pazartesi'si (`mondayKeyOf(plan.updatedAt)`) ile bu haftanın Pazartesi'si farklıysa, yeni hafta başlamış sayılır: madde varsa otomatik arşivle+sıfırla (aynı `archiveAndResetPlanForNewWeek()`), madde yoksa sadece `updatedAt`'i sessizce ilerletir (tekrar tekrar kontrol etmesin diye). Bu durumda kartta "Yeni hafta başladı — geçen hafta otomatik arşivlendi ✓" notu beliriyor. **Sınırlama:** koç paneli haftada en az bir kez açılmazsa tetiklenmez — sunucu tarafı zamanlanmış görev yok, sadece panel açılışına bağlı.
  - Genel not: ayrı textarea + "Notu Kaydet" butonu.
  - **"geçmiş haftalar"** açılır liste (plan editörünün altında) — `fetchPlanHistory()` ile ilk açılışta yüklenir (sonraki açıp-kapamalarda tekrar sorgu atmaz, kart bazlı `historyLoaded` bayrağıyla önbelleklenir; arşivleme sonrası bayrak sıfırlanıp liste açıksa yeniden yüklenir). Her arşiv satırı tıklanınca o haftanın salt-okunur tablosunu (Gün/Konu/Süre/Soru/D/Y/Tik, silme sütunu yok) ve varsa o zamanki genel notu gösterir.

## Haftalık Plan ↔ Günlük Konu Hedefi Entegrasyonu
- Öğrenci girişi/senkronunda (`mergeTodayPlanIntoTopics()`, her 3 dakikada bir tekrar çalışır) o günün haftaiçi karşılığına (`new Date().getDay()` → mon/tue/...) denk gelen plan maddeleri, yerel `topics-YYYY-MM-DD` listesine otomatik ekleniyor (zaten eklenmiş olan `planTaskId`'ler tekrar eklenmiyor).
- Öğrenci o maddeyi günlük listede tikleyince, `done` durumu Firestore'daki plana da geri yazılıyor (koç tablo'da görüyor).
- **Bilinen tuhaflık:** öğrenci o maddeyi günlük listeden silerse, bir sonraki senkronda (plan hâlâ var olduğu için) yeniden eklenir — kalıcı olarak kaldırmak için koçun planı silmesi gerekir.

## Önemli Mekanik Kararlar (değişmedi)
- **Seri:** günlük toplam çalışma 3 saati geçerse gün "geçerli" sayılır.
- **Odak modu:** 15/25/50dk hazır veya 5-480dk özel; erken çıkışta 30sn uyarı; erken çıkış cezası kazancın %50'si + sonraki seansı yarıya düşüren debuff.
  - **(yeni) Cezasız kısa ara:** seans başına en fazla 2 kez, her biri en fazla 5dk (`MAX_FOCUS_PAUSES`, `FOCUS_PAUSE_MAX_MS`). "Kısa Ara Ver" butonu `pauseFocusSession()`'ı çağırır — stopwatch durur, geri sayım donar (kaydırma: `focusSessionStartTs += pausedMs`), 5dk içinde "Devam Et"e basılmazsa otomatik devam eder. `focusModeState="paused"` önce set edildiği için `toggleStudy()`'nin normalde tetikleyeceği `requestFocusExit()` çağrısı state guard'ı tarafından es geçiliyor — ekstra bir flag gerekmedi.
  - **(yeni) Dikkat dağınıklığı artık sonucu etkiliyor:** sekme/pencere değişimi SADECE `focusModeState==="active"` iken sayılıyor (ara verilmişken veya çıkış-uyarısındayken saymıyor). Tamamlanan seansta her dikkat dağınıklığı ödülü %10 azaltıyor, en fazla %50'ye kadar (`FOCUS_DISTRACTION_PENALTY_PER/MAX`) — debuff çarpanıyla birlikte uygulanıyor (ikisi de varsa art arda çarpılıyor). Özet ekranında "%X azaldı" notu çıkıyor.
  - **(yeni) Ses:** seans tamamlanınca 3 notalı yükselen bir "chime", erken-çıkış uyarısı başlayınca kısa bir "uyarı" bipi çalıyor (`playFocusTone()`, Web Audio API ile sentezleniyor — dosya yok, tamamen kod içinde üretiliyor). `AudioContext` odak moduna girerken (bir tıklama anında, autoplay kısıtlaması olmadan) oluşturuluyor, seans bitince kısa bir gecikmeyle kapatılıyor.
  - **(yeni) Odak seansı istatistikleri (öğrenci tarafı, `?view=topics`):** her seans (tamamlandı/bırakıldı, süre, dikkat dağınıklığı, ara sayısı) `focus-sessions-YYYY-MM-DD` anahtarına loglanıyor (`logFocusSession()`). "son 7 gün · odak seansları" kartı (`loadFocusStats()`, artık ortak `computeFocusStatsSummary()`'yi kullanıyor) tamamlanan/toplam seans, bırakılan seans, ortalama dikkat dağınıklığı, en uzun tamamlanan seansı gösteriyor. ~~Henüz koç paneline senkronlanmıyor~~ **Eklendi:** `buildStudentSummaryPayload()` artık `focusStats: {weekTotal, weekCompleted, weekAbandoned, weekAvgDistractions, weekLongestMinutes}` alanını da senkronluyor (ekstra Firestore kuralı gerekmedi, `info/meta` zaten genel kuralla kapsanıyor). Koç kartının üst istatistik satırına "X/Y odak seansı (7g)" eklendi (cloud.js, `fetchCoachStudents`/kart şablonu).
- **Para/Şehir ekonomisi:** ödül = `çalışılan saat × (seri+20)/20` altın — **artık hem normal kronometrede hem odak modunda** çalışıyor (Kaan'ın talebiyle: önceden SADECE odak modu altın veriyordu).
  - **Normal kronometre (odak dışı):** `accrueStudyGold()`, her saniyelik `renderStudy()` tick'inde çalışır, taban oranın (1x) küçük kesirlerini `pendingStudyGold`'da biriktirir (saniyelik miktar `roundCoins`'in 1 ondalık basamağının altında kaldığı için direkt eklenirse hep 0'a yuvarlanır — bu yüzden 0.1 altına ulaşana kadar bellekte tutulup öyle aktarılıyor). `studyState.running && !focusModeActive` iken çalışır; odak modu aktifken hiç tetiklenmez (çift ödül riski yok).
  - **Odak modu:** taban oranın `FOCUS_REWARD_MULTIPLIER = 1.5` katı veriyor (dikkat dağınıklığı ve debuff çarpanları bu 1.5x'lik taban üzerine uygulanıyor). Erken çıkış cezası da aynı 1.5x taban üzerinden hesaplanan "potansiyel ödül"ün %50'si.
  - **Önemli senkron detayı:** odak modu sırasında stopwatch (`studyState`) teknik olarak çalışır durumda kalıyor (odak sadece bir kilit/UI katmanı), ama `lastGoldAccrualTs` odağa girerken VE çıkarken `Date.now()`'a sıfırlanıyor — böylece odak süresi normal-kronometre altınına hiç karışmıyor, sadece odağın kendi 1.5x ödülü sayılıyor.
- **Deneme neti:** `net = doğru - yanlış/4`. Boş otomatik hesaplanır.

## YKS 2026 Tahmini Puan/Sıralama Hesaplama (yeni, basitleştirildi)
- **Fonksiyonlar cloud.js'te, global scope'ta** (`yksHamPuan`, `yksTahminiSiralama`, `yksEstimateForRecord`, `buildYksEstimateRow`, `buildYksEstimateRowsHtml`, `formatSiralama`) — html'in kendi IIFE'i cloud.js daha önce yüklendiği için bunları doğrudan çağırabiliyor, ikinci bir kopya yazmaya gerek yok. Öğrenci tarafı (`?view=exam`, `renderExamYksEstimate()`) ve koç paneli (her kartta "tahmini puan ve sıralama" açılır bölümü) aynı fonksiyonları kullanıyor.
- **ÖNEMLİ — bu KESİN bir hesaplama değil, tahmindir:** ÖSYM'nin gerçek katsayıları (yıllık ortalama/standart sapmaya bağlı) resmi olarak yayınlanmıyor. Kullanılan model: her sınav (TYT=120 soru, AYT-SAY/EA/SOZ=80 soru) için taban puan=100, tavan=500, ders bazında EŞİT ağırlıklı katsayı (`400 / toplam_soru_sayısı` — TYT için ~3.33/net, AYT için 5.0/net). Bu rakamlar genel bilinen yaklaşık değerlerdir, ÖSYM'nin o yılki kesin tablosu değildir. Kaan bu yaklaşımı ~%5-10 sapma kabul ederek onayladı.
- **Her deneme AYRI hesaplanıyor, OBP YOK, TYT+AYT birleştirilmiyor** (Kaan'ın düzeltmesiyle — ilk sürümde ortalama+OBP+track-birleştirme vardı, hem kafa karıştırıcıydı hem de bir hataya yol açtı: OBP eklemesi puanı 500 tavanının üzerine taşıyor, bu da sıralama tablosunun en üst ankor noktasına (puan≥500 → sıralama 100) yanlışlıkla kilitleniyordu — örn. 103.88 TYT net ortalaması "~501 puan, ~100 sıralama" gibi absürt bir sonuç veriyordu). Şimdiki mantık: her deneme kaydı **sadece kendi net'iyle** (`yksHamPuan(examKey, net)`) kendi ham puanını ve sıralamasını üretiyor; farklı tarihli TYT/AYT denemelerini eşleştirme veya ortalama alma yok.
- **Sıralama tahmini:** `YKS_SIRALAMA_ANKORLARI` — puan→sıralama için genel bilinen taban puan/sıralama referanslarından (tıp/mühendislik/ortalama bölüm aralıkları vb.) türetilmiş ~17 ankor noktası, aralarında log-uzayda enterpolasyon (sıralama katlanarak büyüdüğü için doğrusal değil). Resmi bir ÖSYM tablosu değil. `formatSiralama()` sonucu "~" öneki ve yuvarlama ile gösteriyor (örn. "~21.000") — yanlış kesinlik hissi vermemek için. `yksHamPuan` içindeki 100-500 clamp'i sayesinde puan artık hiçbir zaman 500'ü aşmıyor (önceki OBP-taşma hatası bu şekilde çözüldü).
- **Görünüm:** `buildYksEstimateRowsHtml(records)` verilen ham deneme kayıtlarının HER BİRİ için (en yeniden en eskiye sıralı) tek bir satır üretiyor: "22.9.2026 · TYT (adı varsa) — 103.88 net → ~446 puan, ~21.000 sıralama". Liste kısaltılmıyor, tüm kayıtlar gösteriliyor (mevcut "denemeler" listesiyle tutarlı).
- **Öğrenci tarafı:** `?view=exam` sayfasında "net grafiği" kartının altına "tahmini YKS 2026 puanı ve sıralaması" kartı eklendi (`examYksEstimateBox`, `renderExamYksEstimate()` — kayıt/silme/sayfa açılışında yeniden hesaplanıyor).
- **Koç paneli:** her öğrenci kartında "net grafiği"nin altına ayrı bir açılır "tahmini puan ve sıralama" bölümü eklendi — kart oluşturulurken (`examRecords` zaten mevcut) hesaplanıp gömülüyor, ekstra Firestore okuması yok.
- Her iki tarafta da altında sabit bir uyarı notu var: bunun bir TAHMİN olduğu, her denemenin kendi netiyle ayrı hesaplandığı, OBP'nin dahil olmadığı ve TYT/AYT'nin birleştirilmediği belirtiliyor.

## Bilinen Açık Riskler / Yapılacaklar
- ~~Şifre sıfırlama akışı yok.~~ **Eklendi:** giriş ekranında "Şifremi unuttum" (sadece giriş modunda görünür) → `sendPasswordReset(email)` (cloud.js) → Firebase'in `sendPasswordResetEmail`'i, e-posta Türkçe (`fbAuth.languageCode = "tr"`). E-posta numaralandırma koruması açık olduğu için kayıtlı olmayan adreste de hata dönmez; mesaj bilerek "kayıtlıysa gönderildi" diyor. Başarılı gönderimden sonra 30 sn bekleme süresi var. Sıfırlama sayfası Firebase'in kendi barındırdığı sayfa (widget dışı), ekstra ayar gerekmiyor.
- ~~Kayıt sonrası davet kodu değiştirme/girme arayüzü yok.~~ **Eklendi:** öğrenci tarafında "ayarlar" panelinin altına "koç bağlantısı" bölümü geldi (yks-sayac.html). Bağlantı durumu (`currentUserProfile.coachId`) gösteriliyor, davet kodu girip "Bağlan"a basınca zaten var olan `redeemInviteCode(uid, code)` (cloud.js) çağrılıyor — aynı fonksiyon kayıt akışında da kullanılıyordu, yeni bir backend mantığı gerekmedi. Yeniden kod girmek mevcut bağlantıyı da değiştiriyor (yeni `coachId` eskisinin üzerine yazılıyor). Ekstra Firestore kuralı gerekmedi: `users/{uid}` zaten kendi `coachId`'ini güncelleyebiliyordu, `inviteCodes/{code}` zaten herkese `get` izni veriyordu.
- Koç panelinde arama/filtreleme yok (öğrenci sayısı arttıkça gerekebilir).
- ~~Plan sistemi tek şablon — gerçek "geçmiş haftalar arşivi" yok.~~ **Eklendi:** `studentData/{uid}/planHistory/{weekId}` koleksiyonu + koç panelinde "geçmiş haftalar" açılır liste (bkz. Firestore Şeması ve Koç Paneli bölümleri). Firestore rules'a `planHistory` için koça-yazma izni eklenmesi gerekti — **konsolde yayınlanmalı**. Arşivleme hem manuel (buton) hem otomatik (`maybeAutoArchiveWeek()`, koç paneli her açıldığında haftanın dönüp dönmediğine bakar) çalışıyor. **Bilinen sınırlama:** otomatik tetikleyici tamamen koç panelinin açılmasına bağlı — arka planda çalışan bir zamanlayıcı/sunucu yok, koç haftalarca panele girmezse arşivleme de o kadar gecikir.
- Firebase Storage kullanılmıyor (kart bağlama şartı geldiği için) — sadece Firestore+Auth (ikisi de kartsız ücretsiz).
- Kullanılan piksel sanatı asset paketleri için kullanıcı lisans sahibi olduğunu beyan etti.
